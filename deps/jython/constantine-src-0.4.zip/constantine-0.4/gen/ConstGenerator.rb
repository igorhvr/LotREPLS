require 'gen/const_generator'
ConstGenerator = Constantine::ConstGenerator